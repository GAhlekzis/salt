## repo
**Maintainer:** [Stibbons](https://github.com/Stibbons)

This plugin mainly add support automatic completion for the repo command line tool:
http://code.google.com/p/git-repo/

* `r` aliases `repo`
